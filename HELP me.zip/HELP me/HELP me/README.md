FindMyDroid
===========

A simple Android app to locate a lost phone via SMS. Simply text the phone a configurable secret message and it will reply with a Google Maps link to it's location.

