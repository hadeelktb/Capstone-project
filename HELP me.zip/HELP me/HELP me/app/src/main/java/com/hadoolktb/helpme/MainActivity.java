package com.hadoolktb.helpme;

import android.content.Intent;
import android.preference.PreferenceFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.hadoolktb.helpme.AboutActivity;

public class MainActivity extends AppCompatActivity
{
    private View menuInflater;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(com.fernan.findmydroid.R.layout.activity_main);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(com.fernan.findmydroid.R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();
        if (id == com.fernan.findmydroid.R.id.action_about)
        {
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public View getMenuInflater() {
        return menuInflater;
    }

    public static class PreferencesFragment extends PreferenceFragment
    {
        @Override
        public void onCreate(Bundle savedInstanceState)
        {
            try
            {
                super.onCreate(savedInstanceState);
                addPreferencesFromResource(com.fernan.findmydroid.R.xml.preferences);
            }
            catch (Exception ex)
            {
                Log.d("MainActivity", ex.toString());
            }
        }
    }
}
