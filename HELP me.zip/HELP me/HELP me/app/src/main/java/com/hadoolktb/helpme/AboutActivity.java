package com.hadoolktb.helpme;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;

public class AboutActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(com.fernan.findmydroid.R.layout.activity_about);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        return false;
    }
}
